پک «پک تست Wanger» برای واتس‌اپ — ساخته‌شده با @Wanger_Motionbot

این فایل ZIP شامل استیکرها (01.webp، 02.webp …)، آیکون پک (tray.png) و مشخصات پک (pack.json) است.
واتس‌اپ خودش فایل ZIP را باز نمی‌کند: فایل را روی گوشی ذخیره کن و با یک برنامه‌ی واردکننده‌ی استیکر واتس‌اپ که خودت به آن اعتماد داری باز کن.

----

WhatsApp pack “پک تست Wanger” — made with @Wanger_Motionbot

This ZIP holds the stickers (01.webp, 02.webp …), the pack icon (tray.png) and the pack details (pack.json).
WhatsApp doesn’t open ZIP files itself: save the file on your phone and open it with a WhatsApp sticker importer app you trust.
